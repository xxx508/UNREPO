# To-do list for program.cpp

* [ ] File I/O (input: basic table with EOF or with number of rows)
* [ ] Better search
