﻿namespace s03_07_VAR
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.B_CALC = new System.Windows.Forms.Button();
            this.B_NYCALC = new System.Windows.Forms.Button();
            this.buttonresults = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // B_CALC
            // 
            this.B_CALC.AutoSize = true;
            this.B_CALC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.B_CALC.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_CALC.Location = new System.Drawing.Point(12, 155);
            this.B_CALC.Name = "B_CALC";
            this.B_CALC.Size = new System.Drawing.Size(243, 137);
            this.B_CALC.TabIndex = 0;
            this.B_CALC.Text = "Счёты";
            this.B_CALC.UseVisualStyleBackColor = true;
            // 
            // B_NYCALC
            // 
            this.B_NYCALC.AutoSize = true;
            this.B_NYCALC.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_NYCALC.Location = new System.Drawing.Point(12, 12);
            this.B_NYCALC.Name = "B_NYCALC";
            this.B_NYCALC.Size = new System.Drawing.Size(243, 137);
            this.B_NYCALC.TabIndex = 1;
            this.B_NYCALC.Text = "Дни до нового года";
            this.B_NYCALC.UseVisualStyleBackColor = true;
            // 
            // buttonresults
            // 
            this.buttonresults.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.buttonresults.Location = new System.Drawing.Point(13, 299);
            this.buttonresults.Name = "buttonresults";
            this.buttonresults.Size = new System.Drawing.Size(242, 127);
            this.buttonresults.TabIndex = 2;
            this.buttonresults.Text = "Результаты счётов";
            this.buttonresults.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(268, 438);
            this.Controls.Add(this.buttonresults);
            this.Controls.Add(this.B_NYCALC);
            this.Controls.Add(this.B_CALC);
            this.Name = "MainForm";
            this.Text = "Выбор действий";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button B_CALC;
        private System.Windows.Forms.Button B_NYCALC;
        private System.Windows.Forms.Button buttonresults;
    }
}

