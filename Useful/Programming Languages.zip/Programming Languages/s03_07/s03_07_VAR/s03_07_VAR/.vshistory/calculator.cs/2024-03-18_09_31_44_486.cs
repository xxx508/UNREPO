﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace s03_07_VAR
{
    public partial class calculator : Form
    {
        public calculator()
        {
            InitializeComponent();
            B_1.Click += new EventHandler(BClick);
            B_2.Click += new EventHandler(BClick);
            B_3.Click += new EventHandler(BClick);
            B_4.Click += new EventHandler(BClick);
            B_5.Click += new EventHandler(BClick);
            B_6.Click += new EventHandler(BClick);
            B_7.Click += new EventHandler(BClick);
            B_8.Click += new EventHandler(BClick);
            B_9.Click += new EventHandler(BClick);
            B_0.Click += new EventHandler(BClick);
            B_PLUS.Click += new EventHandler(BClick);
            B_MINUS.Click += new EventHandler(BClick);
            B_EQUAL.Click += new EventHandler(BClick);
            B_CLR.Click += new EventHandler(BClick);
        }

        private void calculator_Load(object sender, EventArgs e)
        {

        }
        private int ShowResult(object sender, EventArgs e, int state = 0)
        {
            if (state == -1)
            {
                if (TB_INPUT.Text == "")
                    TB_RESULT.Text = "";
                TB_INPUT.Text = "";
                return 0;
            }
            int result = 0;
            char lastgo = 'n';
            int lastint = 0;
            for (int i = 0; i < TB_INPUT.Text.Length; i++)
            {
                if (TB_INPUT.Text[i] >= '0' && TB_INPUT.Text[i] <= '9')
                {
                    lastint = lastint * 10 + TB_INPUT.Text[i] - 48;
                }
                else
                {
                    if (lastgo == 'n')
                    {
                        result = lastint;
                        lastint = 0;
                    }
                    else
                    {
                        if (lastgo == '-')
                        {
                            result = result - lastint;
                            lastint = 0;
                        }
                        else
                        {
                            result = result + lastint;
                            lastint = 0;
                        }
                    }
                    lastgo = TB_INPUT.Text[i];
                }
            }
            if (lastgo == 'n')
                result = lastint;
            else
            {
                if (lastgo == '-')
                    result -= lastint;
                else
                    result += lastint;
            }
            TB_RESULT.Text = Convert.ToString(result);
            return result;
        }
        private void WriteResult(object sender, EventArgs e)
        {
            int resh = ShowResult(sender, e);
        }
        private void BClick(object sender, EventArgs e)
        {
            switch ((sender as Button).Name)
            {
                case "B_1": { TB_INPUT.Text += "1"; break; }
                case "B_2": { TB_INPUT.Text += "2"; break; }
                case "B_3": { TB_INPUT.Text += "3"; break; }
                case "B_4": { TB_INPUT.Text += "4"; break; }
                case "B_5": { TB_INPUT.Text += "5"; break; }
                case "B_6": { TB_INPUT.Text += "6"; break; }
                case "B_7": { TB_INPUT.Text += "7"; break; }
                case "B_8": { TB_INPUT.Text += "8"; break; }
                case "B_9": { TB_INPUT.Text += "9"; break; }
                case "B_0": { TB_INPUT.Text += "0"; break; }
                case "B_PLUS":
                    {
                        if (TB_INPUT.Text.Length == 0) goto P_Expl;
                        if (TB_INPUT.Text[TB_INPUT.Text.Length - 1] == '+' ||
                            TB_INPUT.Text[TB_INPUT.Text.Length - 1] == '-')
                        {
                            string st = TB_INPUT.Text.Substring(0, TB_INPUT.Text.Length - 1);
                            TB_INPUT.Text = st;
                        }
                    P_Expl:;
                        TB_INPUT.Text += "+";
                        break;
                    }
                case "B_MINUS":
                    {
                        if (TB_INPUT.Text.Length == 0) goto M_Expl;
                        if (TB_INPUT.Text[TB_INPUT.Text.Length - 1] == '+' ||
                            TB_INPUT.Text[TB_INPUT.Text.Length - 1] == '-')
                        {
                            string st = TB_INPUT.Text.Substring(0, TB_INPUT.Text.Length - 1);
                            TB_INPUT.Text = st;
                        }
                    M_Expl:;
                        TB_INPUT.Text += "-";
                        break;
                    }
                case "B_EQUAL":
                    {
                        ShowResult(sender, e);
                        WriteResult(sender, e);
                        break;
                    }
                case "B_CLR":
                    {
                        ShowResult(sender, e, -1);
                        break;
                    }
            }
        }
    }
}
