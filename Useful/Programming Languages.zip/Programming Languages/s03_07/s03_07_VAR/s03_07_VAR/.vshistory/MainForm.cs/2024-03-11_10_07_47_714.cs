﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace s03_07_VAR
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            B_CALC.Click += new System.EventHandler(B_CALC_CLICK);
            B_NYCALC.Click += new System.EventHandler(B_NYCALC_CLICK);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void B_CALC_CLICK(object sender, EventArgs e)
        {
            calculator calc = new calculator();
            calc.ShowDialog(this);
            calc.Close();
        }

        private void B_NYCALC_CLICK(Object sender, EventArgs e)
        {
            newyearrange nyrng = new newyearrange();
            nyrng.ShowDialog(this);
            nyrng.Close();
        }
    }
}
