﻿namespace s03_07_VAR
{
    partial class calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.B_3 = new System.Windows.Forms.Button();
            this.B_6 = new System.Windows.Forms.Button();
            this.B_9 = new System.Windows.Forms.Button();
            this.B_8 = new System.Windows.Forms.Button();
            this.B_5 = new System.Windows.Forms.Button();
            this.B_2 = new System.Windows.Forms.Button();
            this.B_1 = new System.Windows.Forms.Button();
            this.B_4 = new System.Windows.Forms.Button();
            this.B_7 = new System.Windows.Forms.Button();
            this.B_0 = new System.Windows.Forms.Button();
            this.B_MINUS = new System.Windows.Forms.Button();
            this.B_PLUS = new System.Windows.Forms.Button();
            this.B_EQUAL = new System.Windows.Forms.Button();
            this.TB_INPUT = new System.Windows.Forms.TextBox();
            this.L_INPUT = new System.Windows.Forms.Label();
            this.L_RESULT = new System.Windows.Forms.Label();
            this.TB_RESULT = new System.Windows.Forms.TextBox();
            this.B_CLR = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // B_3
            // 
            this.B_3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_3.Location = new System.Drawing.Point(124, 12);
            this.B_3.Name = "B_3";
            this.B_3.Size = new System.Drawing.Size(50, 47);
            this.B_3.TabIndex = 0;
            this.B_3.Text = "3";
            this.B_3.UseVisualStyleBackColor = true;
            // 
            // B_6
            // 
            this.B_6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_6.Location = new System.Drawing.Point(124, 65);
            this.B_6.Name = "B_6";
            this.B_6.Size = new System.Drawing.Size(50, 47);
            this.B_6.TabIndex = 1;
            this.B_6.Text = "6";
            this.B_6.UseVisualStyleBackColor = true;
            // 
            // B_9
            // 
            this.B_9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_9.Location = new System.Drawing.Point(124, 118);
            this.B_9.Name = "B_9";
            this.B_9.Size = new System.Drawing.Size(50, 47);
            this.B_9.TabIndex = 2;
            this.B_9.Text = "9";
            this.B_9.UseVisualStyleBackColor = true;
            // 
            // B_8
            // 
            this.B_8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_8.Location = new System.Drawing.Point(68, 118);
            this.B_8.Name = "B_8";
            this.B_8.Size = new System.Drawing.Size(50, 47);
            this.B_8.TabIndex = 3;
            this.B_8.Text = "8";
            this.B_8.UseVisualStyleBackColor = true;
            // 
            // B_5
            // 
            this.B_5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_5.Location = new System.Drawing.Point(68, 65);
            this.B_5.Name = "B_5";
            this.B_5.Size = new System.Drawing.Size(50, 47);
            this.B_5.TabIndex = 4;
            this.B_5.Text = "5";
            this.B_5.UseVisualStyleBackColor = true;
            // 
            // B_2
            // 
            this.B_2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_2.Location = new System.Drawing.Point(68, 12);
            this.B_2.Name = "B_2";
            this.B_2.Size = new System.Drawing.Size(50, 47);
            this.B_2.TabIndex = 5;
            this.B_2.Text = "2";
            this.B_2.UseVisualStyleBackColor = true;
            // 
            // B_1
            // 
            this.B_1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_1.Location = new System.Drawing.Point(12, 12);
            this.B_1.Name = "B_1";
            this.B_1.Size = new System.Drawing.Size(50, 47);
            this.B_1.TabIndex = 6;
            this.B_1.Text = "1";
            this.B_1.UseVisualStyleBackColor = true;
            // 
            // B_4
            // 
            this.B_4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_4.Location = new System.Drawing.Point(12, 65);
            this.B_4.Name = "B_4";
            this.B_4.Size = new System.Drawing.Size(50, 47);
            this.B_4.TabIndex = 7;
            this.B_4.Text = "4";
            this.B_4.UseVisualStyleBackColor = true;
            // 
            // B_7
            // 
            this.B_7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_7.Location = new System.Drawing.Point(12, 118);
            this.B_7.Name = "B_7";
            this.B_7.Size = new System.Drawing.Size(50, 47);
            this.B_7.TabIndex = 8;
            this.B_7.Text = "7";
            this.B_7.UseVisualStyleBackColor = true;
            // 
            // B_0
            // 
            this.B_0.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_0.Location = new System.Drawing.Point(68, 171);
            this.B_0.Name = "B_0";
            this.B_0.Size = new System.Drawing.Size(50, 47);
            this.B_0.TabIndex = 9;
            this.B_0.Text = "0";
            this.B_0.UseVisualStyleBackColor = true;
            // 
            // B_MINUS
            // 
            this.B_MINUS.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_MINUS.Location = new System.Drawing.Point(124, 171);
            this.B_MINUS.Name = "B_MINUS";
            this.B_MINUS.Size = new System.Drawing.Size(50, 47);
            this.B_MINUS.TabIndex = 10;
            this.B_MINUS.Text = "-";
            this.B_MINUS.UseVisualStyleBackColor = true;
            // 
            // B_PLUS
            // 
            this.B_PLUS.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_PLUS.Location = new System.Drawing.Point(12, 171);
            this.B_PLUS.Name = "B_PLUS";
            this.B_PLUS.Size = new System.Drawing.Size(50, 47);
            this.B_PLUS.TabIndex = 11;
            this.B_PLUS.Text = "+";
            this.B_PLUS.UseVisualStyleBackColor = true;
            // 
            // B_EQUAL
            // 
            this.B_EQUAL.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.B_EQUAL.Location = new System.Drawing.Point(12, 224);
            this.B_EQUAL.Name = "B_EQUAL";
            this.B_EQUAL.Size = new System.Drawing.Size(162, 47);
            this.B_EQUAL.TabIndex = 12;
            this.B_EQUAL.Text = "=";
            this.B_EQUAL.UseVisualStyleBackColor = true;
            // 
            // TB_INPUT
            // 
            this.TB_INPUT.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.TB_INPUT.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.TB_INPUT.Location = new System.Drawing.Point(180, 65);
            this.TB_INPUT.Multiline = true;
            this.TB_INPUT.Name = "TB_INPUT";
            this.TB_INPUT.ReadOnly = true;
            this.TB_INPUT.Size = new System.Drawing.Size(467, 153);
            this.TB_INPUT.TabIndex = 13;
            // 
            // L_INPUT
            // 
            this.L_INPUT.AutoSize = true;
            this.L_INPUT.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.L_INPUT.Location = new System.Drawing.Point(180, 24);
            this.L_INPUT.Name = "L_INPUT";
            this.L_INPUT.Size = new System.Drawing.Size(153, 30);
            this.L_INPUT.TabIndex = 14;
            this.L_INPUT.Text = "Ввод действий";
            this.L_INPUT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // L_RESULT
            // 
            this.L_RESULT.AutoSize = true;
            this.L_RESULT.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.L_RESULT.Location = new System.Drawing.Point(180, 236);
            this.L_RESULT.Name = "L_RESULT";
            this.L_RESULT.Size = new System.Drawing.Size(106, 30);
            this.L_RESULT.TabIndex = 15;
            this.L_RESULT.Text = "Результат";
            this.L_RESULT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TB_RESULT
            // 
            this.TB_RESULT.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.TB_RESULT.Location = new System.Drawing.Point(292, 231);
            this.TB_RESULT.Name = "TB_RESULT";
            this.TB_RESULT.ReadOnly = true;
            this.TB_RESULT.Size = new System.Drawing.Size(355, 35);
            this.TB_RESULT.TabIndex = 16;
            // 
            // B_CLR
            // 
            this.B_CLR.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.B_CLR.Location = new System.Drawing.Point(612, 12);
            this.B_CLR.Name = "B_CLR";
            this.B_CLR.Size = new System.Drawing.Size(40, 40);
            this.B_CLR.TabIndex = 17;
            this.B_CLR.Text = "CLR";
            this.B_CLR.UseVisualStyleBackColor = true;
            // 
            // calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 285);
            this.Controls.Add(this.B_CLR);
            this.Controls.Add(this.L_RESULT);
            this.Controls.Add(this.TB_RESULT);
            this.Controls.Add(this.L_INPUT);
            this.Controls.Add(this.TB_INPUT);
            this.Controls.Add(this.B_EQUAL);
            this.Controls.Add(this.B_PLUS);
            this.Controls.Add(this.B_MINUS);
            this.Controls.Add(this.B_0);
            this.Controls.Add(this.B_7);
            this.Controls.Add(this.B_4);
            this.Controls.Add(this.B_1);
            this.Controls.Add(this.B_2);
            this.Controls.Add(this.B_5);
            this.Controls.Add(this.B_8);
            this.Controls.Add(this.B_9);
            this.Controls.Add(this.B_6);
            this.Controls.Add(this.B_3);
            this.Name = "calculator";
            this.Text = "Калькулятор";
            this.Load += new System.EventHandler(this.calculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button B_3;
        private System.Windows.Forms.Button B_6;
        private System.Windows.Forms.Button B_9;
        private System.Windows.Forms.Button B_8;
        private System.Windows.Forms.Button B_5;
        private System.Windows.Forms.Button B_2;
        private System.Windows.Forms.Button B_1;
        private System.Windows.Forms.Button B_4;
        private System.Windows.Forms.Button B_7;
        private System.Windows.Forms.Button B_0;
        private System.Windows.Forms.Button B_MINUS;
        private System.Windows.Forms.Button B_PLUS;
        private System.Windows.Forms.Button B_EQUAL;
        private System.Windows.Forms.TextBox TB_INPUT;
        private System.Windows.Forms.Label L_INPUT;
        private System.Windows.Forms.Label L_RESULT;
        private System.Windows.Forms.TextBox TB_RESULT;
        private System.Windows.Forms.Button B_CLR;
    }
}