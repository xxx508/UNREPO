﻿#include <iostream>
#include <stdio.h>
#include <cstdio>
#include <algorithm>
#include <cstring>
//#include "examples.cpp"
using namespace std;

bool primar(unsigned n) {
	for (unsigned i = 2; i < n / 2 + 1; i++) {
		if (n % i == 0)return 0;
	}
	return 1;
}

unsigned prim(unsigned n) {
	unsigned i;
	for (i = n + 1; i < 10 * n; i++) {
		if (primar(i))break;
	}
	return i;
}

void L5_20_1() {
	cout << "Insert primary number: ";
	unsigned n;
	cin >> n;
	if (!primar(n)) cout << "This is not a primary number!\n";
	cout << "Next primary number is: " << prim(n);
}

void maxx(int* arr, int n) {
	int m = -_I32_MAX;
	for (int i = 0; i < n; i++) {
		if (arr[i] > m)m = arr[i];
	}
	cout << m;
}

void maxx(char* str) {
	int i, ml = 0, l, ce, me = 0;
	int s = 0;
	for (i = 0; str[i] != '\0'; ++i)++s;
	for (i = 0; i <= s && str[i] != '\0';) {
		l = 0;
		ce = i;
		while (str[i++] != ' ' && i <= s)l++;
		if (ml < l) {
			me = ce;
			ml = l;
		}
	}
	cout << "\nThe biggest word is:\n";
	for (i = me; i < me + ml; ++i) {
		if (str[i] < 'A') { ml--; break; }
		cout << str[i];
	}
	printf("\n(%d characters)\n", ml);
}

void L5_20_21() {
	int* array, n, x;
	cout << "Number of elements in array, random(0 for manual input): "; cin >> n >> x;
	array = new int[n];
	if (x) {
		cout << "Array:\n";
		for (int i = 0; i < n; i++) { array[i] = rand() % x; cout << array[i] << " "; }cout << endl;
	}
	else { for (int i = 0; i < n; i++)cin >> array[i]; }
	cout << "Max element is "; maxx(array, n);
}

void L5_20_22() {
	char* str = new char[(int)1e3]; int i;
	cout << "Insert string:\n";
	for (i = 0; i < (int)1e3; ++i)str[i] = '\0';
	getchar();
	cin.getline(str, (int)1e3);
	maxx(str);
}

void listm() {
		cout << "List of contents(var 20):\n"
			<< "___\n0: exit\n"
			<< "___\n1:\nInsert>>primary number;\nOut<<next primary numer\n"
			<< "___\n2:\nInsert>>Array of N el. (rand/not);\nOut<<max_element\n"
			<< "___\n3:\nInsert>>String;\nOut<<most long word;\n";
}

int main()
{
	listm();
	setlocale(LC_ALL, "Russian");
	srand((unsigned)time(NULL));
	int l = 1;
	g:
	while (l) {
		cout << "\n# = ";
		cin >> l;
		switch (l) {
		case 1:L5_20_1(); break;
		case 2:L5_20_21(); break;
		case 3:L5_20_22(); break;
		default: goto g;
		}
		goto g;
		return 0;
	}
}