#include <iostream>
#include <stdio.h>
#include <cmath>
using namespace std;

void ent(){cout<<endl;}

int Sum(int a, char b, char c);

float Cub(float f){return pow(f,3);}

int Sq(int arg){return arg*arg;}

double Sq(double arg){return arg*arg;}

void print(int i){printf("%d ", i);}
void print(double x){printf("%f ", x);}
void print(char* s){printf("%s ", s);}

void p1(){
	int x,y;
	cin>>x;
	y=Cub(x);
	cout<<"\nx^3 = "<<y;
	cout<<"\nx^3 = "<<Cub(x);
	ent();
}

void p2(){
	int x,y,z,S;
	cin>>x>>y>>z;
	S=Sum(x,y,z);
	cout<<"\nSumma "<<x<<"+"<<y<<"+"<<z<<"="<<S;
	cout<<"\nSumma 2 = "<<Sum(4,3,-2);
	ent();
}

void hello(void){cout<<"Hello World!\n";}

void p3(){
	cout<<"Primer: ";
	hello();
	ent();
}

void p4(){
	int x=11;
	double y=3.1416;
	printf("%d squared = %d, %f squared = %f \n",x,Sq(x),y,Sq(y));
}

void p5(){
	int j=5;
	double pi=3.1415926;
	double e;
	e=pow((double)(1+(double)1/20),20);
	print(j); print(e); print(pi);
	ent();
	hello();
}
void list(){
	cout<<"\nExamples:\n";
}

void main2(){
	setlocale(LC_ALL, "Russian");
	srand(time(NULL));
	list();
	cout<<"p1:";p1();
	cout<<"p2:";p2();
	cout<<"p3:";p3();
	cout<<"p4:";p4();
	cout<<"p5:";p5();
	cout<<"print helloworld:";hello();
}

int Sum(int a, char b, char c){
	return a+b+c;
}