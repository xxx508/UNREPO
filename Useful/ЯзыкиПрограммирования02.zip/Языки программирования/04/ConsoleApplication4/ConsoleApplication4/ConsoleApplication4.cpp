﻿#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <algorithm>
using namespace std;
void list() {
	cout << "1 - 3: Examples 1-3;\n"
		<< "4: Array of N elemens, randomly or not-randomly generated.\n"
		<< "   It sorts with insert, and search for insertion with binary srch\n"
		<< "   Example input:\n_Kol:_ <number of elements>\n_Rand?_ <0 for no-random; x for random, elements'll be gen within [-x/2;x/2]>\n"
		<< "5: Array of N elements, randomly or not-randomly generated.\n"
		<< "   Program searches how many elements we may exclude to get increasing arr\n"
		<< "   Example input:\n_Kol:_ <number of elements>\n_Rand?_ <0 for no-random; x for random, elements'll be gen within [-x/2;x/2]>\n"
		<< "6: Generates 2-d arr from x*x elements, inserting elements spirally\n"
		<< "7: 6, in other way";
}

void p1() {
	int i, a[6], s = 0; float sred;
	for (i = 0; i < 6; i++)
	{
		cout << "Vvedite element N" << i << ":";
		cin >> a[i];
		s += a[i];
	}
	sred = (float)s / 6;
	cout << "Srednee znachenie v massive: " << sred << "\n";
}

void p2() {
	int i, * ip, N, S = 0;
	cin >> N;
	ip = new int[N];
	if (ip != NULL)
	{
		cout << "Massiv sozdan uspeshno. \n";
		for (i = 0; i < N; i++)
		{
			cout << "Vvedite " << i << "-j element: ";
			cin >> *(ip + i);
			S += ip[i];
		}
		cout << "Summa elementov: " << S << "\n";
		delete ip;
	}
	else cout << "Oshibka bideleniya dinamicheskoy pamyaty! \n";
}

void p3() {
	int i, j, * ip, N, M, S = 0, * m, mx = 0, c = 0, x;
	cin >> N; cin >> M;
	ip = new int[N * M];
	m = new int[N];
	for (i = 0; i < N; i++) { m[i] = 0; };
	if (ip != NULL)
	{
		cout << "\n********** Massiv ********** \n";
		srand((unsigned)time(NULL));
		for (j = 0; j < M; j++)
		{
			for (i = 0; i < N; i++)
			{
				x = *(ip + i + j * N) = rand() % 100;
				cout << x << " ";
				m[i] = m[i] + x;
				S += x;
			}
			cout << "\n";
		}
		cout << "\nSumma: " << S << "\n";
		delete[] ip;
	}
	else cout << "Error ! \n";
	for (i = 0; i < N; i++)
	{
		if (mx < m[i]) { mx = m[i]; c = i; };
	}
	cout << "max stolbec = " << c + 1 << " ego summa = " << m[c];
}

int dv(int* M, int x, int r) {
	int l = -1, n;
	while (r-l>1) {
		n = (r + l) / 2;
		if (M[n] > x)r = n;
		else l = n;
	}
	return r;
}

unsigned len(unsigned m) {
	int i, n = m;
	for (i = 1; n; i++, n /= 10);
	return i;
}

void L4_30_1() {
	int* M, * M_S, x, i, n, j, ni=0, lg=0; //M, M_S = unsorted, sorted arr; lg = len of sorted arr; ni = num insert to M_S;
	cout << "Kol: "; cin >> n;
	M = M_S = new int[n];
	cout << "Rand? "; cin >> x; //41
	if (x) {
		for (i = 0; i < n; i++) {
			M[i] = (rand() % x) - x / 2; cout << M[i] << " ";
		}
		cout << endl;
	}
	else {
		for (i = 0; i < n; i++) {
			cin >> M[i];
		}
	}
	M_S[0] = M[0];
	lg++;
	for (i = lg; i < n; i++) {
		x = M[i];
		ni = dv(M_S, x, lg);
		if (x > M_S[lg - 1])M_S[lg] = x;
		else {
			for (j = lg; j > ni; j--)M_S[j] = M_S[j - 1];
			M_S[j] = x;
		}
		lg++;
	}
	for (i = 0; i < n; i++)cout << M_S[i] << " ";
}

void L4_30_2() {
	int* M, n, x, i, j, d[INT16_MAX], ans;
	cout << "Kol: "; cin >> n;
	M = new int[n];
	cout << "Rand? "; cin >> x;
	if (x) {
		for (i = 0; i < n; i++) {
			M[i] = (rand() % x) - x / 2; cout << M[i] << " ";
		}
		cout << endl;
	}
	else { for (i = 0; i < n; i++)cin >> M[i]; }
	for (int i = 0; i < n; ++i) {
		d[i] = 1;
		for (int j = 0; j < i; ++j)
			if (M[j] < M[i])
				d[i] = max(d[i], 1 + d[j]);
	}

	ans = d[0];
	for (int i = 0; i < n; ++i)
		ans = max(ans, d[i]);
	cout << n-ans << endl;
}

void L4_30_3() {
	unsigned i, n, ** massiv; int x, y, b[2];
	x = y = 0;
	cout << "Kol: "; cin >> n;
	b[0] = n;
	b[1] = 0;
	massiv = new unsigned* [n];
	for (i = 0; i < n; i++)massiv[i] = new unsigned[n];
	for (i = 1; i < n * n;) {
		while (x < b[0]) {
			massiv[x][y] = i;
			i++;
			x++;
		}
		x--;
		i--;
		while (y < b[0]) {
			massiv[x][y] = i;
			i++;
			y++;
		}
		y--;
		i--;
		b[0] -= 1;
		while (x > b[1] - 1) {
			massiv[x][y] = i;
			i++;
			x--;
		}
		i--;
		x++;
		while (y > b[1]) {
			massiv[x][y] = i;
			i++;
			y--;
		}
		i--;
		y++;
		b[1] += 1;
	}
	if (n == 1)cout << 1;else 
	for (y = 0; y < n; y++) {
		for (x = 0; x < n; x++) {
			b[0] = massiv[x][y];
			for (i = 0; i < len(n * n)-len(b[0]); i++)cout << " ";
			cout << " ";
			cout << b[0];
		}
		cout << endl;
	}
}

void L4_30_3_1() {
	unsigned** massiv; int x, y, b[2], nap = 1, i, j, k, p = 1, n, lb;
	x = y = 0;
	cout << "Diagonal: "; cin >> n;
	b[0] = n;
	b[1] = -1;
	massiv = new unsigned* [n];
	for (i = 0; i < n; i++)massiv[i] = new unsigned[n];
	while (1) {
		switch (nap)
		{
		case 1: {j = x; k = b[0]; }break;
		case 2: {j = y; k = b[0]--; }break;
		case 3: {j = x; k = b[1]++; }break;
		case 4: {j = y; k = b[1]; }break;
		default:
			break;
		}
		if (nap < 3) {
			for (i = j; i < k; i++) {
				switch (nap) {
				case 1: {massiv[i][y] = p++; x = i; }break;
				case 2: {massiv[x][i] = p++; y = i; }break;
				}
			}
		}
		else {
			for (i = j; i > k; i--) {
				switch (nap) {
				case 3: {massiv[i][y] = p++; x = i; }break;
				case 4: {massiv[x][i] = p++; y = i; }break;
				}
			}
		}
		p--;
		nap++;
		if (nap == 5)nap = 1;
		if (p >= n * n)break;
	}
	for (y = 0; y < n; y++) {
		for (x = 0; x < n; x++) {
			b[0] = massiv[x][y];
			i = 0;
			lb = len(n) - len(b[0]) + 2;
			for (; i < lb; i++)cout << " ";
			cout << b[0];
		}
		cout << endl;
	}
}

int main()
{
	setlocale(LC_ALL, "Russian");
	srand((unsigned)time(NULL));
	list();
	int l = 1, cont = 0;
	while (l) {
	B:;
		cout << "\n # = ";
	A:;
		if (cont) {
			cout << "\n Continue? ";
			cin >> cont;
			if (cont)goto AG; else goto B;
		}
		cont++;
		cin >> l;
	AG:;
		switch (l) {
		case 1: p1(); goto A;
		case 2: p2(); goto A;
		case 3: p3(); goto A;
		case 4:L4_30_1(); goto A;
		case 5:L4_30_2(); goto A;
		case 6:L4_30_3(); goto A;
		case 7:L4_30_3_1(); goto A;
		default: break;
		}
	}
	return 0;
}