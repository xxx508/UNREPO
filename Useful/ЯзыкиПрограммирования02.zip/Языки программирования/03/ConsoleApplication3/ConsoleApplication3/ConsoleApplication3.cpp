﻿#include <iostream>
#include <conio.h>
using namespace std;

void pr1() {
	int i, a, b;
	cout << "Enter a: "; cin >> a;
	cout << "Enter b: "; cin >> b;
	for (i = a; i <= b; i++) cout << i << " ";
}

void pr2() {
	int i, N;
	long int S=1;
	cout << "N = "; cin >> N;
	for (S = 1, i = 1; i <= N; i++) S *= i;
	cout << N << "! = " << S;
}

void pr3() {
	unsigned int N, m;
	cout << "N = "; cin >> N;
	m = N % 10;
	while (N > 10) N /= 10;
	cout << "Sum = " << N + m;
}

void pr4() {
	unsigned long n, m, k;
	int f=0;
	cout << "n = "; cin >> n;
	cout << "m = "; cin >> m;
	do {
		k = n % 10;
		if (k == m) f++;
		n /= 10;
	} while (n > 0);
	if (f) cout << f; else cout << "Net.";
}

void L3_13_1() {
	unsigned long m, n, i=1;
	cout << "Числитель = "; cin >> m;
	cout << "Знаменатель = "; cin >> n;
	if (n == m) { n = m = 1; goto d; }
	for (i = 2; i < 1000; i++) {
		while (n % i == 0 && m % i == 0) {
			n /= i;
			m /= i;
		}
	}
d:;
	cout << "Полученная дробь = " << m << "/" << n;
}

void L3_13_2() {
	unsigned a, b, i=1, n;
	cin >> a >> b;
	if (a == b) { cout << "A = B => 1 квадрат"; goto e; }
	else {
		if (a > b)n = b; else n = a;
		while (a!=1||b!=1)
		{
			if (a > b) {
				i++;
				a -= n;
			}
			else {
				i++;
				b -= n;
			}
			if (a > b)n = b; else n = a;
		}
		if (a > b) {
			i += a-1;
		}
		else { i += b - 1; }
	}
	cout << i;
e:;
}

int kol(int i) {
	int s = 0;
	while (i) {
		s+=i%10;
		i /= 10;
	}
	return s;
}

void L3_13_3() {
	unsigned i, m=1e+4, k=0;
	for (i = 1000; i < 10000; i++) {
		if ((kol(i) == 28 || kol(i) == 29) && (i % 10 == 7))
		{
			if (m > i) m = i;
			k++;
		}
	}
	cout << "Количество = " << k << " Минимальное = " << m;
}

int main(){
	setlocale(LC_ALL, "Russian");
	unsigned i=1;
	for (i; i;) {
	l:;
		cout << "\n# = ";
		cin >> i;
		switch (i) {
		case 1:L3_13_1(); break;
		case 2:L3_13_2(); break;
		case 3:L3_13_3(); break;
		default: break;
		}
	}
}