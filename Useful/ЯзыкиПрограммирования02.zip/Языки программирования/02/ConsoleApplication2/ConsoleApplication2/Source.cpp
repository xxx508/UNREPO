#include <iostream>
#include <cmath>
using namespace std;
const double PI = 3.14159;
double pi2deg(double a, int b) {
	switch (b) {
	case 1: return (a * 180 / PI); break; //rad->deg
	case 2: return (a * PI / 180); break; //deg->rad
	default: return 0; break;
	}
}
/*
double pifagor(double x1, double y1, double x2, double y2) {
	return sqrt(pow((x2 - x1),2) + pow((y2 - y1),2));
}
double opranglecos(double a, double b, double c) {
	return pi2deg(acos((b * b + a * a - c * c) / (2 * a * b)),1);
}
int sdlin(int sd, int nach) {
	if (sd < 0) {
		nach = nach << abs(sd);
	}
	else {
		nach = nach >> sd;
	}
	return nach;
}
int sdcic(int sd, int nach) {
	int np, nl, n;
	if (sd<0) {
		np = nach >> (32 - abs(sd));
		nl = nach << sd;
		n = np | nl;
	}
	else {
		np = nach >> sd;
		nl = nach << (32 - abs(sd));
		n = np | nl;
	}
	return n;
}
int sdvig() {
	char pod,p;
	int sd,nach;
	cout << "In cycle? Y/N ";
	cin >> pod;
	switch(pod) {
		case 'Y': {
			cout << "(yc)Where and how much? <L/R><how much> ";
			cin >> p >> sd;
			if (p == 'L') sd=sd*(-1);
			cout << "First statement: "; cin >> nach;
			cout << "Second statement: " << sdcic(sd, nach);
			break;
		}
		case 'N': {
			cout << "(nc)Where and how much? <L/R><how much> ";
			cin >> p >> sd;
			if (p == 'L') sd=sd*(-1);
			cout << "First statement: "; cin >> nach;
			cout << "Second statement: " << sdlin(sd, nach);
		}
	}
	return 0;
}
int spcbysin() {
	double x1, y1, x2, y2, x3, y3, c1, c2, c3, a, s;
	x1 = x2 = x3 = y1 = y2 = y3 = c1 = c2 = c3 = a = s = 0;
	cin >> x1, y1, x2, y2, x3, y3;
	c1 = pifagor(x1, y1, x2, y2);
	c2 = pifagor(x2, y2, x3, y3);
	c3 = pifagor(x3, y3, x1, y1);
	a = opranglecos(c1, c2, c3);
	s = pi2deg(a, 2) * c1 * c2 / 2;
	cout << s;
	return 0;
}*//*
void someX() {
	double x1, x2, A, B, C;
	cout << "X0="; cin >> x1; cout << "X1="; cin >> x2; cout << "A="; cin >> A;
	C = x1 * x2 * A;
	B = -(x2 + x1) * A;
	cout << A << "x^2 + " << B << "x + " << C;
	if ((abs(B * B) - 4 * A * C) < 0) {cout << "\n��������� �� ����� ����� �������";};
}
void cic() {
	unsigned short x, xr, xl, r=3;
	cout << "X = ";	cin >> x;
	xr = x << r;
	xl = x >> (16 - r);
	x = xr | xl;
	cout << x;
}
double dis() {
	double a, b, c, d;
	cout << "A, B, C: "; cin >> a >> b >> c;
	d = (b * b) - (4 * a * c);
	if (d < 0) { cout << "��������� �� ����� �������"; };// goto endp;};
	if (d == 0) { cout << "X1 = X2 = " << ((-b) / (2 * a)); };// goto endp;};
	if (d > 0) { cout << "X1 = " << ((-b + sqrt(d)) / (2 * a)) << "; X2 = " << ((-b - sqrt(d)) / (2 * a)); };
endp:;
	cout << "\n";
	return 0;
}
void ch() {
	unsigned char l;
	cout << "S = "; cin >> l;
	cout << "Num = " << (int)l;
	l--;
	cout << "; [-1] = " << l;
	l+=2;
	cout << "; [+1] = " << l;
}*/

/*double ak(double x1, double y1, double x2, double y2) {
	double k;
	k = (abs(y1 - y2) / abs(x1 - x2));
	return k;
}
int pr(double x1, double y1, double x2, double y2, double x3, double y3) {
	if (abs(x3 - x2) == abs(x2 - x1) && abs(y3 - y2) == abs(y2 - y1)) cout << "YES";
	else cout << pi2deg(atan(abs(ak(x1, y1, x2, y2) - ak(x2, y2, x3, y3))),1);
	return 0;
}*/
int prL21() {
	int a, b;
	cout << "1: "; cin >> a;
	cout << "2: "; cin >> b;
	if (a > b)cout << "a > b\n";
	else cout << "b >= a\n";
	return 0;
}
int prL22() {
	int a, b;
	cout << "1: "; cin >> a;
	cout << "2: "; cin >> b;
	if (a > b) { cout << "a > b\n" << "a - b = " << a - b; }
	else {
		if (a == b) cout << "a = b\n";
		else cout << "b > =a\n" << "b - a = " << b - a;
		return 0;
	}
}
int main() {
	setlocale(LC_ALL, "Russian");
	prL21();
	prL22();
	return 0;
}
