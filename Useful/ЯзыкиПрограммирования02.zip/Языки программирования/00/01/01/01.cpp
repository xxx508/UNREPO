﻿#include <iostream>
#include <string>

void rline(char* L, char S) {
	char i = 0; int s=0;
	while ((i=getchar()) != S) {
		L[s++] = i;
	}
	L[s++] = i;
}

bool sline(char* f, char* s) {
	int l=0, cl=0;
	for (; *f != ' ' && *s != ' '; l++) {
		if (*f++ == *s++)cl++;
	}
	if (l = cl)
		return 1;
	else
		return 0;
}

void cl(char* a) {
	while (*(a++) != '\n')
		std::cout << *a;
	std::cout << std::endl;
}


int main()
{
	int B, A; char** NAM, ** NB, * CN, **IZ; bool* skip;
	std::cin >> B;
	NAM = NB = IZ = new char* [B]; skip = new bool[B];
	CN = new char[256];
	for (int i = 0; i < B; i++) {
		IZ[i] = new char[256];
		NAM[i] = new char[256];
		rline(NAM[i], ' ');
		NB[i] = new char[256];
		rline(NB[i], '\n');
		skip[i] = 0;
	}
	for (int i = 0; i < B; i++) {
		if (skip[i])continue;
		CN = NAM[i];
		for (int j = i + 1; j < B; j++) {
			skip[i] = sline(CN, NAM[j]);
		}
	}
	for (int i = 0; i < B; i++) {
		if (!skip[i]) {
			cl(NB[i]);
		}
	}
	return 0;
}