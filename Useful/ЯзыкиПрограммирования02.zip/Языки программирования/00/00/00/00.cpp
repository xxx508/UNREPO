﻿#include <iostream>
#include <algorithm>
using namespace std;

int bs(int* M, int n, int q) {
	int l = 0, r = n - 1, m = (r + l) / 2;
	while (1) {
		m = (r + l) / 2;
		if (r - l < 2)break;
		if (M[m] > q) { r = m-1; continue; }
		if (M[m] < q) { l = m+1; continue; }
	}
	return l;
}

int main() {
	int* m, k, n, q, index;
	cin >> n>> k;
	m = new int[n];
	for (int i = 0; i < n; i++)cin >> m[i];
	for (int i = 0; i < k; i++) {
		cin >> q;
		index = bs(m, n, q);
		cout << index << endl;
	}
}