﻿#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

void psort(int* M, int mlen) {
	for (int i = 0; i < mlen; i++) {
		for (int j = 0; j < mlen-1; j++) {
			if (M[j] > M[j + 1]) {
				swap(M[j], M[j + 1]);
			}
		}
	}
}

void psort(char* M, int mlen) {
	for (int i = 0; i < mlen; i++) {
		for (int j = 0; j < mlen - 1; j++) {
			if (M[j] > M[j + 1]) {
				swap(M[j], M[j + 1]);
			}
		}
	}
}

void func1() {
	int COLN, n, * posl, * res, x, count[2]{0/*red*/,0/*blue*/}, sum[2]{0/*red*/,0/*blue*/};
	cin >> COLN;
	res = new int[COLN];
	for (int k = 0; k < COLN; k++) {
		cin >> n;
		posl = new int[n];
		for (int j = 0; j < n; j++) {
			cin >> x;
			posl[j] = x;
		}
		psort(posl, n);
		int j = n - 1;
		for (int i = 0; i < n; i++) {
			if (sum[0] > sum[1]) {
				if (count[0] < count[1]) {
					res[k] = 1;
					goto H;
				}
				else {
					sum[1] += posl[i];
					count[1]++;
				}
			}
			else {
				sum[0] += posl[j];
				count[0]++;
				j--;
			}
		}
		res[k] = 0;
	H:;
		delete[] posl; count[0] = 0; count[1] = 0; sum[0] = 0; sum[1] = 0;
	}
	for (int i = 0; i < COLN; i++) {
		if (res[i])cout << "YES\n";
		else cout << "NO\n";
	}
}

void func2() {
	int COLN;
	int len[2], kolmax, k[3], va, vb, vc; char* a, * b, * c; /*len = len[a,b], kolmax=max oper, k=[curr zapas oper a, b, currop], vc=var2mass[c], va=var2mass[a], vb=var2mass[b]*/
	cin >> COLN;
	for (int kit = 0; kit < COLN; kit++) {
		cin >> len[0] >> len[1] >> kolmax;
		a = new char[len[0]];
		b = new char[len[1]];
		c = new char[len[0] + len[1]];
		cin.getline(b,len[1]);
		psort(a, len[0]);
		psort(b, len[1]);
		k[0] = k[1] = kolmax;
		k[2] = 1;
		va = vb = vc = 0;
		while (len[0]&& len[1]) {
			switch (k[2]) {
			case 1: {
				if (k[0]) {
					c[vc] = a[va];
					va++;
					vc++;
					len[0]--;
					k[0]--;
				}
				else {
					k[0] = kolmax;
					k[2] = 2;
				}
			}
			case 2: {
				if (k[1]) {
					c[vc] = b[vb];
					vb++;
					vc++;
					len[1]--;
					k[1]--;
				}
				else {
					k[1] = kolmax;
					k[2] = 1;
				}
			}
			default: break;
			}
		}
		for (int i = 0; i < vc; i++) {
			cout << c[i];
		}
		delete[] a, b, c;
	}
}

int main()
{
	//func1();
	func2();
}