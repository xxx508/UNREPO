﻿//bfstree

//#include <iostream>
//#include <vector>
//#include <queue>
//
//using namespace std;
//
//vector<vector<int>>graph;
//vector<bool>used;
//vector<int>d;
//queue<int>q;
//int len = 0, bg, x;
//
//void bfs() {
//	while (!q.empty()) {
//		x = q.front();
//		if (!used[x]) {
//			for (auto i : graph[x]) {
//				if (!used[i]){
//					q.push(i);
//					d[i] = d[x] + 1;}}
//			used[x] = 1;
//			q.pop();
//			if (len < d[x]) {
//				len = d[x];
//				bg = x;
//			}
//		}
//		else {	q.pop();	}	}	}
//
//int main() {
//	int n, u, v;	cin >> n;
//	graph.resize(n+1);	used.resize(n+1, 0);	d.resize(n+1, 0);
//	for (int i = 0; i < n; i++) {
//		cin >> u >> v;
//		graph[u - 1].push_back(v - 1);
//		graph[v - 1].push_back(u - 1);
//	}
//	q.push(0);	bfs();
//	d.clear();	d.resize(n + 1, 0);	used.clear();	used.resize(n+1, 0);
//	q.push(bg);	bfs();
//	cout << len;
//	return 0;}

//dfstree

//#include <iostream>
//#include <vector>
//#include <queue>
//using namespace std;
//
//vector<vector<int>>graph;
//vector<bool>col;
//vector<int>depth;
//pair<int, int>mx(0, 0);
//int nodes;
//
//void dfs(int v) {
//	col[v] = true;
//	for (vector<int>::iterator i = graph[v].begin(); i != graph[v].end(); ++i)
//		if (!col[*i]) {
//			depth[*i] = depth[v] + 1;
//			if (mx.second < depth[*i]) {
//				mx.first = *i;
//				mx.second = depth[*i];
//			}
//			dfs(*i);
//		}
//}
//void rs() {
//	col.clear(); depth.clear();
//	graph.resize(nodes);
//	depth.resize(nodes, 0);
//	col.resize(nodes, 0);
//}
//
//int main() {
//	int u, v;
//	cin >> nodes;
//	rs();
//	for (int i = 1; i < nodes; i++) {
//		cin >> u >> v;
//		graph[u - 1].push_back(v - 1);
//		graph[v - 1].push_back(u - 1);
//	}
//	dfs(0);
//	rs();
//	dfs(mx.first);
//	cout << mx.second;
//	return 0;
//}


//cfs

//1676G

//#include <iostream>
//#include <vector>
//
//struct node {
//	int parent;
//	std::vector<int> child;
//	int col;
//};
//
//std::vector<node>graph;
//int nodes, ans;
//std::vector<int>as;
//
//void insert() {
//
//	int u;
//	char col;
//
//	std::cin >> nodes;
//
//	graph.resize(nodes);
//	graph[0].parent = -1;
//
//	for (int i = 1; i < nodes; i++) {
//		std::cin >> u;
//		graph[u - 1].child.push_back(i);
//		graph[i].parent = u - 1;
//
//	} //insert graph structure
//
//	for (int i = 0; i < nodes; i++) {
//		std::cin >> col;
//		if (col == 'W') {
//			graph[i].col = 1;
//		}
//		else
//		{
//			graph[i].col = -1;
//		}
//	} //insert colors
//}
//
//void dfs(int y) {
//	for (auto i : graph[y].child) {
//		dfs(i);
//	}
//	if (y > 0) {
//		if (!graph[y].col)
//			ans++;
//		graph[graph[y].parent].col += graph[y].col;
//	}
//	else
//	{	
//		for (auto i : graph[0].child) {
//			graph[0].col += graph[i].col;
//		}
//		if (!graph[0].col)
//			ans++;
//	}
//}
//
//int main() {
//	int funcs;
//	std::cin >> funcs;
//	as.resize(funcs);
//	for (int i = 0; i < funcs; i++) {
//		ans = 0;
//		insert();
//		dfs(0);
//		as[i] = ans;
//		graph.clear();
//	}
//	for (auto i : as)
//		std::cout << i << '\n';
//	return 0;
//}

//1143C

//#include <iostream>
//#include <vector>
//#include <queue>
//#include <algorithm>
//using namespace std;
//
//vector<pair<int, vector<int>>>gr;
//vector<bool>note;
//vector<int>ans;
//vector<int>used;
//queue<int>q;
//int nodes, desc, kegli = 0;
//
//void insert() {
//	int parent; bool state;
//	for (int i = 0; i < nodes; i++) {
//		cin >> parent >> state;
//		if (parent == -1) {
//			gr[i].first = parent;
//			desc = i;
//		}
//		else {
//			gr[i].first = parent - 1;
//			gr[parent - 1].second.push_back(i);
//		}
//		if (state) {
//			note[i] = 1;
//			kegli++;
//		}
//	}
//}
//
//void bfs() {
//	while (!q.empty()&&kegli>0)
//	{
//		int x = q.front();
//		for (auto k : gr[x].second) {
//			if(!used[k])
//				q.push(k);
//		}
//		if (note[x]) {
//			bool o = 1;
//			for (auto k : gr[x].second) {
//				if (!note[k])
//					o = 0;
//				q.push(k);
//			}
//			if (o) {
//				ans.push_back(x);
//				note[x] = 0;
//				kegli--;
//			}
//
//		}
//		if (!gr[x].second.size() && note[x]) {
//			ans.push_back(x);
//			kegli--;
//		}
//		used[x] = 1;
//		q.pop();
//	}
//}
//
//int main() {
//	ios_base::sync_with_stdio(false);
//	cin.tie(NULL);
//	cin >> nodes;
//	gr.resize(nodes);
//	note.resize(nodes, 0);
//	used.resize(nodes, 0);
//	insert();
//	if (nodes == 1) {
//		cout << -1;
//		return 0;
//	}
//	q.push(desc);
//	if(kegli>=nodes-1)
//		for (int i = 1; i < nodes+1; i++) {
//			cout << i << ' ';
//		}
//	if (kegli)
//		bfs();
//	if (ans.size()) {
//		sort(ans.begin(), ans.end());
//		for (auto a : ans)
//			cout << a + 1 << ' ';
//	}
//	else
//		cout << -1;
//}

//1092F

//#include <vector>
//#include <iostream>
//using namespace std;
//
//long long peaksum, ans;
//vector<vector<int>> gr;
//vector<int> a;
//vector<int> h;
//vector<long long> sum;
//int nodes, mnode;
//
//void dfs(int x, int p = -1) {
//	if(x>0)
//		h[x] = h[p] + 1;
//	peaksum += (long long) h[x] * a[x];
//	sum[x] = a[x];
//	for (auto i : gr[x]) {
//		if (i == p) {
//			continue;
//		}
//		dfs(i, x);
//		sum[x] += sum[i];
//	}
//}
//
//void sch(int x, int prt = -1) {
//	if (peaksum > ans) {
//		ans = peaksum;
//		mnode = x;
//	}
//	for (auto y : gr[x]) {
//		if (y == prt)
//			continue;
//		peaksum -= sum[y];		sum[x] -= sum[y];
//		peaksum += sum[x];		sum[y] += sum[x];
//		sch(y, x);
//		sum[y] -= sum[x];		peaksum -= sum[x];
//		sum[x] += sum[y];		peaksum += sum[y];
//	}
//}
//
//void insert() {
//	int c, d;
//	for (int i = 0; i < nodes; i++) {
//		cin >> a[i];
//	}
//	for (int i = 0; i < nodes - 1; i++) {
//		cin >> c >> d;
//		gr[c-1].push_back(d-1);
//		gr[d-1].push_back(c-1);
//	}
//}
//
//int main() {
//	cin >> nodes;
//	a.resize(nodes);
//	sum.resize(nodes);
//	gr.resize(nodes);
//	insert();
//	h.resize(nodes);
//	h[0] = 0;
//	dfs(0);
//	sch(0);
//	cout << ans << " " << mnode;
//	return 0;
//}

//1675F

//#include <iostream>
//#include <vector>
//
//using namespace std;
//
//vector<int>aNS;
//vector<vector<int>> g;
//vector<bool> tlist, d;
//int nodes, tks;
//
//void dfs(int vert, int prnt = -1) {
//    for (int u : g[vert]) {
//        if (u != prnt) {
//            dfs(u, vert);
//            if (tlist[u])
//                tlist[vert] = 1;
//            if (d[u])
//                d[vert] = 1;
//        }
//    }
//}
//
//void insert() {
//    int u, a, b;
//    cin >> nodes >> tks;
//    g.clear();
//    g.resize(nodes);
//    int addr[2];
//    cin >> addr[0] >> addr[1];
//    addr[0]-=1;
//    addr[1]-=1;
//    tlist.clear();
//    d.clear();
//    tlist.resize(nodes, 0);
//    d.resize(nodes, 0);
//    for (int i = 0; i < tks; ++i) {
//        cin >> u;
//        u-=1;
//        tlist[u] = 1;
//    }
//    d[addr[1]] = 1;
//    for (int i = 0; i < nodes - 1; ++i) {
//        cin >> a >> b;
//        g[a-1].push_back(b-1);
//        g[b-1].push_back(a-1);
//    }
//    dfs(addr[0]);
//    int ans = 0;
//    for (int i = 0; i < nodes; ++i) {
//        if (i == addr[0])
//            continue;
//        if (d[i])
//            ++ans;
//        else
//            if (tlist[i])
//                ans += 2;
//    }
//    aNS.push_back(ans);
//}
//
//int main() {
//    ios_base::sync_with_stdio(false);
//    cin.tie(0);
//    cout.tie(0);
//    int funcs;
//    cin >> funcs;
//    while (funcs--)
//        insert();
//    for (auto i : aNS)
//        cout << i << '\n';
//}


//1092F

#include <stdio.h>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

const int N = 200 * 1000 + 13;
const int INF = INT32_MAX;

int nodes, edges, dist_a[N], dist_b[N];
vector<int> g[N], cur;
bool used[N];

int bfs(int x, int dia[N]) {
	queue<int> que;
	que.push(x);
	dia[x] = 0;
	int last = -1;
	while (!que.empty()) {
		int v = que.front();
		que.pop();
		last = v;
		for (auto u : g[v]) if (dia[u] > dia[v] + 1) {
			dia[u] = dia[v] + 1;
			que.push(u);
		}
	}
	return last;
}

void dfs(int v) {
	used[v] = true;
	cur.push_back(v);
	for (auto u : g[v]) if (!used[u])
		dfs(u);
}

void insert()
{
	scanf_s("%i%i", &nodes, &edges);
	for (int i = 0; i < edges; i++)
	{
		int v, u;
		scanf_s("%i%i", &v, &u);
		--v, --u;
		g[v].push_back(u);
		g[u].push_back(v);
	}
}

int main() {
	insert();
	for(int i = 0; i < nodes;i++) dist_a[i] = dist_b[i] = INF;
	vector<pair<int, int>> comps;
	for (int i = 0; i < nodes; i++)
		if (!used[i]) {
			cur.clear();
			dfs(i);
			int x = bfs(i, dist_a);
			int y = bfs(x, dist_b);
			for (auto v : cur) dist_a[v] = INF;
			bfs(y, dist_a);
			int d = dist_b[y], center;
			for (auto v : cur) if (dist_a[v] == d / 2 && dist_b[v] == d - d / 2)
				center = v;
			comps.push_back({ d, center });
		}
	vector<pair<int, int>> ans;
	nth_element(comps.begin(), comps.end() - 1, comps.end());
	for (int i = 0; i< int(comps.size()) - 1; i++) {
		g[comps[i].second].push_back(comps.back().second);
		g[comps.back().second].push_back(comps[i].second);
		ans.push_back({ comps[i].second, comps.back().second });
	}
	for(int i = 0; i < nodes;i++)
		dist_a[i] = dist_b[i] = INF;
	int y = bfs(bfs(comps.back().second, dist_a), dist_b);
	printf("%i\n", dist_b[y]);
	for (auto i : ans)
		printf("%i %i\n", i.first + 1, i.second + 1);
	return 0;
}