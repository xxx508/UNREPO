#include <iostream>
#include <vector>

struct node {
	int parent;
	std::vector<int> child;
	int col;
};

std::vector<node>graph;
int nodes, ans;
std::vector<int>as;

void insert() {

	int u;
	char col;

	std::cin >> nodes;

	graph.resize(nodes);
	graph[0].parent = -1;

	for (int i = 1; i < nodes; i++) {
		std::cin >> u;
		graph[u - 1].child.push_back(i);
		graph[i].parent = u - 1;

	} //insert graph structure

	for (int i = 0; i < nodes; i++) {
		std::cin >> col;
		if (col == 'W') {
			graph[i].col = 1;
		}
		else
		{
			graph[i].col = -1;
		}
	} //insert colors
}

void dfs(int y) {
	for (auto i : graph[y].child) {
		dfs(i);
	}
	if (y > 0) {
		if (!graph[y].col)
			ans++;
		graph[graph[y].parent].col += graph[y].col;
	}
	else
	{	
		for (auto i : graph[0].child) {
			graph[0].col += graph[i].col;
		}
		if (!graph[0].col)
			ans++;
	}
}

int main() {
	int funcs;
	std::cin >> funcs;
	as.resize(funcs);
	for (int i = 0; i < funcs; i++) {
		ans = 0;
		insert();
		dfs(0);
		as[i] = ans;
		graph.clear();
	}
	for (auto i : as)
		std::cout << i << '\n';
	return 0;
}