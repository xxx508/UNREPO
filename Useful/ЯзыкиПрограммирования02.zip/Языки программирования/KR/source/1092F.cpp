#include <vector>
#include <iostream>
using namespace std;

long long peaksum, ans;
vector<vector<int>> gr;
vector<int> a, h;
vector<long long> sum;
int nodes, mnode;

void dfs(int x, int p = -1) {
	if(x>0)
		h[x] = h[p] + 1;
	peaksum += (long long) h[x] * a[x];
	sum[x] = a[x];
	for (auto i : gr[x]) {
		if (i == p) {
			continue;
		}
		dfs(i, x);
		sum[x] += sum[i];
	}
}

void sch(int x, int prt = -1) {
	if (peaksum > ans) {
		ans = peaksum;
		mnode = x;
	}
	for (auto y : gr[x]) {
		if (y == prt)
			continue;
		peaksum -= sum[y];		sum[x] -= sum[y];
		peaksum += sum[x];		sum[y] += sum[x];
		sch(y, x);
		sum[y] -= sum[x];		peaksum -= sum[x];
		sum[x] += sum[y];		peaksum += sum[y];
	}
}

void insert() {
	int c, d;
	for (int i = 0; i < nodes; i++) {
		cin >> a[i];
	}
	for (int i = 0; i < nodes - 1; i++) {
		cin >> c >> d;
		gr[c-1].push_back(d-1);
		gr[d-1].push_back(c-1);
	}
}

int main() {
	cin >> nodes;
	a.resize(nodes);
	sum.resize(nodes);
	gr.resize(nodes);
	insert();
	h.resize(nodes);
	h[0] = 0;
	dfs(0);
	sch(0);
	cout << ans << " " << mnode;
	return 0;
}