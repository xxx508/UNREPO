#include <iostream>
#include <vector>

using namespace std;

vector<int>aNS;
vector<vector<int>> g;
vector<bool> tlist, d;
int nodes, tks;

void dfs(int vert, int prnt = -1) {
    for (int u : g[vert]) {
        if (u != prnt) {
            dfs(u, vert);
            if (tlist[u])
                tlist[vert] = 1;
            if (d[u])
                d[vert] = 1;
        }
    }
}

void insert() {
    int u, a, b;
    cin >> nodes >> tks;
    g.clear();
    g.resize(nodes);
    int addr[2];
    cin >> addr[0] >> addr[1];
    addr[0]-=1;
    addr[1]-=1;
    tlist.clear();
    d.clear();
    tlist.resize(nodes, 0);
    d.resize(nodes, 0);
    for (int i = 0; i < tks; ++i) {
        cin >> u;
        u-=1;
        tlist[u] = 1;
    }
    d[addr[1]] = 1;
    for (int i = 0; i < nodes - 1; ++i) {
        cin >> a >> b;
        g[a-1].push_back(b-1);
        g[b-1].push_back(a-1);
    }
    dfs(addr[0]);
    int ans = 0;
    for (int i = 0; i < nodes; ++i) {
        if (i == addr[0])
            continue;
        if (d[i])
            ++ans;
        else
            if (tlist[i])
                ans += 2;
    }
    aNS.push_back(ans);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int funcs;
    cin >> funcs;
    while (funcs--)
        insert();
    for (auto i : aNS)
        cout << i << '\n';
}