#include <stdio.h>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

const int N = 200 * 1000 + 13;
const int INF = INT32_MAX;

int nodes, edges, dist_a[N], dist_b[N];
vector<int> g[N], cur;
bool used[N];

int bfs(int x, int dia[N]) {
	queue<int> que;
	que.push(x);
	dia[x] = 0;
	int last = -1;
	while (!que.empty()) {
		int v = que.front();
		que.pop();
		last = v;
		for (auto u : g[v]) if (dia[u] > dia[v] + 1) {
			dia[u] = dia[v] + 1;
			que.push(u);
		}
	}
	return last;
}

void dfs(int v) {
	used[v] = 1;
	cur.push_back(v);
	for (auto u : g[v]) if (!used[u])
		dfs(u);
}

void insert()
{
	scanf_s("%i%i", &nodes, &edges);
	for (int i = 0; i < edges; i++)
	{
		int v, u;
		scanf_s("%i%i", &v, &u);
		--v, --u;
		g[v].push_back(u);
		g[u].push_back(v);
	}
}

int main() {
	insert();
	for(int i = 0; i < nodes;i++) dist_a[i] = dist_b[i] = INF;
	vector<pair<int, int>> comps;
	for (int i = 0; i < nodes; i++)
		if (!used[i]) {
			cur.clear();
			dfs(i);
			int x = bfs(i, dist_a);
			int y = bfs(x, dist_b);
			for (auto v : cur) dist_a[v] = INF;
			bfs(y, dist_a);
			int d = dist_b[y], center;
			for (auto v : cur) if (dist_a[v] == d / 2 && dist_b[v] == d - d / 2)
				center = v;
			comps.push_back({ d, center });
		}
	vector<pair<int, int>> ans;
	nth_element(comps.begin(), comps.end() - 1, comps.end());
	for (int i = 0; i< int(comps.size()) - 1; i++) {
		g[comps[i].second].push_back(comps.back().second);
		g[comps.back().second].push_back(comps[i].second);
		ans.push_back({ comps[i].second, comps.back().second });
	}
	for(int i = 0; i < nodes;i++)
		dist_a[i] = dist_b[i] = INF;
	int y = bfs(bfs(comps.back().second, dist_a), dist_b);
	printf("%i\n", dist_b[y]);
	for (auto i : ans)
		printf("%i %i\n", i.first + 1, i.second + 1);
	return 0;
}