#include <iostream>
#include <stdio.h>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;

vector<vector<int>>graph;
vector<bool>used;
vector<int>d;
queue<int>q;

void bfs(){
	int x = q.front();
	q.pop();
	while(!q.empty()){
	if(!used[x]){
		for(auto i: graph[x]){
			if(!used[i]){
				q.push(i);
				d[i] = d[x] + 1;
			}
		}
		used[x] = 1;
	}
	}
}

int main(){
	int n, u, v;
	cin>>n;
	graph.resize(n);
	used.resize(n, 0);
	d.resize(n, 0);
	for(int i=0;i<n;i++){
		cin>>u>>v;
		graph[u-1].push_back(v-1);
		graph[v-1].push_back(u-1);
	}
	bfs();
	int len = 0;
	for(auto i : d)
		len = max(len, i);
	bfs();
	for(auto i : d)
		len = max(len, i);
	fstream FO;
	FO.open("Q:\\UNIV\\Учёба\\Семестр 02\\Языки программирования\\KR\\source\\1.txt");
	FO<<len;
	FO.close();
	return 0;
}