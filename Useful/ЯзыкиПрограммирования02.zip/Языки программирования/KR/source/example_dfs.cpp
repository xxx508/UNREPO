#include <vector>
#include <iostream>
using namespace std;

long long peaksum, ans;
vector<vector<int>> gr;
vector<int> a;
vector<long long> sum;
int nodes;

void dfs(int x, int p = -1, int h = 0) {
	peaksum += h * 1ll * a[x];
	sum[x] = a[x];
	for (auto to : gr[x]) {
		if (to == p) {
			continue;
		}
		dfs(to, x, h + 1);
		sum[x] += sum[to];
	}
}

void sch(int x, int prt = -1) {
	ans = max(ans, peaksum);
	for (auto y : gr[x]) {
		if (y == prt)
			continue;
		peaksum -= sum[y];
		sum[x] -= sum[y];
		peaksum += sum[x];
		sum[y] += sum[x];
		sch(y, x);
		sum[y] -= sum[x];
		peaksum -= sum[x];
		sum[x] += sum[y];
		peaksum += sum[y];
	}
}

void insert() {
	int u, v;
	for (int i = 0; i < nodes; i++) {
		cin >> a[i];
	}
	for (int i = 0; i < nodes - 1; i++) {
		cin >> u >> v;
		--u, --v;
		gr[u].push_back(v);
		gr[v].push_back(u);
	}
}

int main() {
	cin >> nodes;
	a.resize(nodes);
	sum.resize(nodes);
	gr.resize(nodes);
	insert();
	dfs(0);
	sch(0);
	cout << ans;
	return 0;
}