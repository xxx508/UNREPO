#include <iostream>
#include <ctime>
#include <algorithm>
using namespace std;

void sort_p(unsigned long *M, unsigned long n){
	clock_t c_start = clock();
	unsigned long mine = 10000000, maxe=0, i, l=0, *C;
	for (i = 0; i < n; i++){
		if (M[i] < mine) mine=M[i];
		if (M[i] > maxe) maxe=M[i];
	}
	C = new unsigned long[maxe - mine + 1];

	for (i = 0; i < maxe - mine + 1; i++) C[i] = 0;

	for (i = 0; i < n; i++) C[M[i] - mine]++;

	for (i = mine; i <= maxe; i++)
		while (C[i - mine]--) M[l++] = i;

	clock_t c_end = clock();
	long double dur = c_end-c_start;
	cout << dur/CLOCKS_PER_SEC << " s\n";
}

void sort_s(unsigned long *M, unsigned long n){
	clock_t c_start = clock();
	sort(M, M+n);
	clock_t c_end = clock();
	long double dur = c_end-c_start;
	cout << dur/CLOCKS_PER_SEC << " s\n";
}
int main() {
	unsigned long n, *M, *M1, x, i;
	cout << "Kol? Rand?\n";
	cin >> n >> x;
	M = M1 = new unsigned long[n];
	for (i = 0; i < n; i++) M[i] = M1[i] = rand()%(x+1);
	cout << "\nPodsch:"; sort_p(M, n);
	cout << "std Sort from C++:\n"; sort_s(M1, n);
}