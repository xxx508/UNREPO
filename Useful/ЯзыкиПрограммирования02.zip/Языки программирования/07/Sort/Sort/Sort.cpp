﻿#include <iostream>
#include <ctime>
#include <vector>
#include <algorithm>
#include <string>
#include <fstream>
#include <chrono>
using namespace std;

void printarr(unsigned long* M, unsigned long len) {
	for (int i = 0; i < len; i++)cout << M[i] << " ";
}

void cend() {
	cout << "________\nexample end\n________\n";
}

auto sort_p(unsigned long *M, unsigned long n) {
	auto c_start = chrono::steady_clock::now();
	unsigned long mine = (unsigned long)1e7, maxe = 0, i, l = 0, * C;
	for (i = 0; i < n; ++i) {
		if (M[i] < mine)mine = M[i];
		if (M[i] > maxe)maxe = M[i];
	} //search for minmax
	C = new unsigned long[maxe - mine+1]; //pointer to arr
	for (unsigned long i = 0; i < maxe - mine+1; i++)C[i] = 0; //arr & -> el.kol.
	for (i = 0; i < n; i++) {
		C[M[i]-mine]++;
	}
	for (i = mine; i <= maxe; i++) {
		while (C[i-mine]--) {
			M[l++] = i;
		}
	}
	auto c_end = chrono::steady_clock::now();
	if (n < 20)printarr(M, n);
	chrono::duration<double>elapsed = c_end - c_start;
	cout << endl << elapsed.count() << " s\n";
}

auto s_sort(unsigned long* M, unsigned long n) {
	auto c_start = chrono::steady_clock::now();
	sort(M, M+n);
	auto c_end = chrono::steady_clock::now();
	if (n < 20)printarr(M, n);
	chrono::duration<double>elapsed = c_end - c_start;
	cout << endl << elapsed.count() << " s\n";
}

int sort_s() {
	unsigned long n, *M, *M1, x;
	fstream INSTATEMENT;
	string filepath;
	cout << "\nm(manual)/filepath/e(exit)\n";
	cin >> filepath; cout << endl;
	if (filepath !="m"&&filepath!="e") {
		INSTATEMENT.open(filepath);
		int Nexp;
		INSTATEMENT >> Nexp;
		for (int i = 0; i < Nexp; i++) {
			INSTATEMENT >> n >> x;
			cout << "num = " << n << " rand% = " << x;
			M = M1 = new unsigned long[n];
			if (n < 20)cout << "Massiv:\n";
			for (unsigned long i = 0; i < n; i++) M[i] = M1[i] = rand() % x;
			if (n < 20)printarr(M, n);
			cout << "\nPodsch:";
			sort_p(M, n);
			cout << "std Sort from C++:\n";
			s_sort(M1, n);
			cend();
			delete[] M, M1;
		}
	}
	else if(filepath!="e"){
		cout << "Kol? Rand?\n";
		cin >> n >> x;
		M = M1 = new unsigned long[n];
		if (n < 20)cout << "Massiv\n";
		for (unsigned long i = 0; i < n; i++) { M[i] = M1[i] = rand() % (x+1); if (n < 20)cout << M[i] << " "; }
		cout << "\nPodsch:";
		sort_p(M, n);
		cout << "std Sort from C++:\n";
		s_sort(M1, n);
		cend();
		delete[] M, M1;
	}
	if (filepath == "e")return 0;
}

int main() {
	int i = 1;
	srand((unsigned)time(NULL));
	while (i) { 
		i = sort_s();
	}
}